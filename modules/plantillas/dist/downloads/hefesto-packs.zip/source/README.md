# Editar y recompilar

Copia ../gallery como dist dentro de esta carpeta y copia ../integration a dist/integration. Ejecuta npm install y npm run build. La primera construcción regenera los packs y ZIP. Abre dist/index.html para revisar. No incluye configuración de hosting ni credenciales.

Originales: src/directions.cjs (dirección por rubro), src/design-engine.js (HTML), src/design.css, src/experience.js (GSAP), src/three-scene.js (3D).
