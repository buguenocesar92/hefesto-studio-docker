# Hefesto Design Collection · Vol. 02

48 rubros, 12 familias visuales, tres tratamientos por rubro.

- Abre gallery/index.html para explorar las vistas sin instalar dependencias.
- packs/ contiene los HTML y bases de integración. Conserva gallery/assets junto al resto del paquete: contiene fotos y librerías locales.
- Las descargas desde la galería offline apuntan al sitio; todos los packs ya están descomprimidos en packs/.
- source/src contiene los originales de diseño, animación GSAP y escenas Three.js; los recursos compilados están en gallery/assets.
- Lee integration/README.md para Laravel, WordPress y los otros sistemas.

Las fotos son referencias visuales, no productos reales ni trabajos propios. Créditos y licencias: gallery/assets/THIRD-PARTY-NOTICES.md.

Las vistas son demos, no instalaciones completas ni pasarelas de pago.
